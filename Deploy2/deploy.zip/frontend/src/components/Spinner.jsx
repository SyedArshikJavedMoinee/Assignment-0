// NOTE: here should be loadingSpinner on className of inner div
function Spinner() {
  return (
    <div className='loadingSpinnerContainer'>
      <div className='loadingSpinner'></div>
    </div>
  )
}

export default Spinner
